import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Particles from "react-tsparticles";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Pricing from "./components/Pricing";
import Footer from "./components/Footer";
import Loader from "./components/Loader";

export default function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 2000);
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="relative min-h-screen bg-dark overflow-hidden">
      <Particles
        options={{
          background: { color: "#0b0b0b" },
          particles: {
            color: { value: "#ff0000" },
            move: { enable: true, speed: 1 },
            number: { value: 50 },
            size: { value: 2 },
          },
        }}
        className="absolute inset-0 -z-10"
      />
      <Hero />
      <Features />
      <Pricing />
      <Footer />
    </div>
  );
}