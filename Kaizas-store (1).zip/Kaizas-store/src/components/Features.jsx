import React from "react";
import { motion } from "framer-motion";

const features = [
  { title: "Murah", desc: "Hanya RM5/bulan — mampu milik untuk semua." },
  { title: "Stabil", desc: "Server 24 jam tanpa downtime." },
  { title: "Pintar", desc: "Dikuasakan AI moden dan update automatik." },
  { title: "Privasi", desc: "Data pelanggan dilindungi sepenuhnya." },
];

export default function Features() {
  return (
    <section className="py-20 text-center px-4">
      <h2 className="text-3xl font-bold text-red-500 mb-12">Kelebihan Kami</h2>
      <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
        {features.map((f, i) => (
          <motion.div
            key={i}
            className="bg-black bg-opacity-40 p-6 rounded-2xl border border-red-600"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.2 }}
          >
            <h3 className="text-xl font-semibold mb-2 text-white">{f.title}</h3>
            <p className="text-gray-400">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}