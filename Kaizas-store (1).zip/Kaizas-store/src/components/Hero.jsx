import React from "react";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center px-4">
      <motion.img
        src="/logo.png"
        alt="Kaizas Store"
        className="w-28 mb-4"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1 }}
      />
      <motion.h1
        className="text-4xl md:text-6xl font-bold text-red-500"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        Kaizas Store
      </motion.h1>
      <p className="mt-4 text-gray-300 max-w-lg">
        Sewa Bot WhatsApp Premium hanya RM5/bulan — laju, pintar, dan 24 jam
        aktif!
      </p>
      <motion.a
        href="https://wa.me/60193497488?text=Hai+Kaizas,+saya+berminat+nak+sewa+bot+RM5/bulan."
        whileHover={{ scale: 1.1 }}
        className="mt-6 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-semibold shadow-lg"
      >
        Sewa Sekarang
      </motion.a>
    </section>
  );
}