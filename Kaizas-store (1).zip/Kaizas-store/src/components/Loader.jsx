import React from "react";
import { motion } from "framer-motion";

export default function Loader() {
  return (
    <div className="h-screen flex flex-col justify-center items-center bg-black">
      <motion.img
        src="/logo.png"
        alt="Kaizas Store"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1 }}
        className="w-32 h-32 mb-4"
      />
      <motion.p
        className="text-red-500 text-xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
      >
        Loading Kaizas Store...
      </motion.p>
    </div>
  );
}