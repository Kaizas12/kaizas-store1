import React from "react";
import { motion } from "framer-motion";

export default function Pricing() {
  return (
    <section className="py-20 text-center px-4 bg-black bg-opacity-50">
      <h2 className="text-3xl font-bold text-red-500 mb-8">Pelan Harga</h2>
      <motion.div
        className="bg-red-600 p-8 rounded-3xl text-white shadow-2xl inline-block"
        whileHover={{ scale: 1.05 }}
      >
        <h3 className="text-2xl font-bold mb-2">RM5 / Bulan</h3>
        <p className="mb-4">Akses penuh ke bot WhatsApp premium</p>
        <a
          href="https://wa.me/60193497488?text=Hai+Kaizas,+saya+berminat+nak+sewa+bot+RM5/bulan."
          className="bg-black text-red-500 px-6 py-3 rounded-full font-semibold hover:bg-gray-900"
        >
          Sewa Sekarang
        </a>
      </motion.div>
    </section>
  );
}