import React from "react";

export default function Footer() {
  return (
    <footer className="py-6 text-center border-t border-red-800 bg-black bg-opacity-60">
      <p className="text-gray-400 text-sm">
        © 2025 Kaizas Store. All rights reserved.
      </p>
    </footer>
  );
}